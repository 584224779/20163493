package servlet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.gb.model.baike;
import com.gb.util.CheckIfExists;
import com.gb.util.HeadUtil;
@WebServlet("/zidongservlet")
public class zidongservlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    public zidongservlet() 
    {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		this.doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setHeader("Access-Control-Allow-Origin", "*"); 
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		String method = request.getParameter("method");
		System.out.println("method");
		if(method.equals("zidong")) 
		{
			System.out.println("1");
			CheckIfExists checkIfExists=new CheckIfExists();
			JSONObject json = new JSONObject();
			List<JSONObject> jsons = new ArrayList<>();
			List<baike> list=new ArrayList<>();
			try 
			{
				list=checkIfExists.loadAll();
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			String string;
			String str;
			JSONObject json1=null;
			for(baike baike:list)
			{
				json1 = new JSONObject();
				json1.put("type",baike.getType());
				json1.put("name",baike.getName());
				jsons.add(json1);
				System.out.println(json1.get("type"));
				System.out.println(json1.get("name"));
			}
			//json.put("data", jsons);
			System.out.println(jsons);
			response.setCharacterEncoding("utf-8");
			//response.getWriter().write(json.toJSONString());
			response.getWriter().write(jsons.toString());
		}
	}

}
